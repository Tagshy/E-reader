# Leitura — e-reader pessoal Android

Aplicativo Android offline para importar e ler PDFs locais.

## Funcionalidades da versão inicial
- Importar PDFs pelo seletor de documentos do Android.
- Biblioteca com miniaturas da primeira página.
- Leitura com gesto lateral e botões anterior/próxima.
- Salvar última página lida e preferência de tema.
- Modo escuro.

**Ainda não implementado:** animação realista de virar folhas, zoom avançado, estantes personalizadas e edição de capas/títulos. A opção experimental de folhear ainda usa a navegação lateral comum.

## Como gerar APK pelo GitHub
1. Envie o conteúdo deste ZIP para a raiz do repositório GitHub, mantendo as pastas.
2. Abra a aba **Actions** e selecione **Gerar APK Android**.
3. Clique **Run workflow** (ou aguarde a execução automática após o commit).
4. Ao concluir, abra a execução e baixe o artefato **Leitura-APK**.
5. Extraia o arquivo baixado e instale `app-debug.apk` no seu Android.

O GitHub Actions utiliza Gradle 8.9 e Java 17, sem exigir Android Studio local. O APK de debug é para uso pessoal e não para publicação.
